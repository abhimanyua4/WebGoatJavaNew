webgoat.customjs.accessControlMenu = function() {
    //webgoat.customjs.jquery('#ac-menu-ul').menu();
    webgoat.customjs.jquery('#ac-menu').accordion();
}

webgoat.customjs.accessControlMenu();